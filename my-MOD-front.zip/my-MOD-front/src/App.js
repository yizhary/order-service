// src/App.js
import React from 'react';
import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';
import { Provider } from 'react-redux';
import { store } from './app/store';
import ShoppingList from './features/shoppingList/ShoppingList';
import OrderSummary from './features/orderSummary/OrderSummary';
import './App.css'; // Your global styles

function App() {
  return (
    <Provider store={store}>
      <Router>
        <div className="App">
          <Routes>
            <Route path="/" element={<ShoppingList />} />
            <Route path="/summary" element={<OrderSummary />} />
          </Routes>
        </div>
      </Router>
    </Provider>
  );
}

export default App;