// src/app/store.js
import { configureStore } from '@reduxjs/toolkit';
import shoppingListReducer from '../features/shoppingList/shoppingListSlice';
import cartReducer from '../features/cart/cartSlice';

export const store = configureStore({
  reducer: {
    shoppingList: shoppingListReducer,
    cart: cartReducer,
  },
});