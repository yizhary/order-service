// src/features/shoppingList/ProductInput.js
import React, { useState } from 'react';
import { useDispatch } from 'react-redux';
import { addProductToCart } from '../cart/cartSlice'; // Action to add to cart

function ProductInput({ selectedCategory }) {
  const [productName, setProductName] = useState('');
  const [quantity, setQuantity] = useState(1);
  const dispatch = useDispatch();

  const handleAddProduct = () => {
    if (productName.trim() && quantity > 0) {
      dispatch(addProductToCart({
        id: Date.now(), // Simple unique ID
        category: selectedCategory,
        name: productName.trim(),
        quantity: Number(quantity),
      }));
      setProductName('');
      setQuantity(1);
    }
  };

  return (
    <div>
      <h3>Add Product to {selectedCategory}</h3>
      <input
        type="text"
        placeholder="Product Name"
        value={productName}
        onChange={(e) => setProductName(e.target.value)}
      />
      <input
        type="number"
        min="1"
        value={quantity}
        onChange={(e) => setQuantity(e.target.value)}
      />
      <button onClick={handleAddProduct}>Add Product to Cart</button>
    </div>
  );
}

export default ProductInput;