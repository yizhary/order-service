// src/features/shoppingList/ShoppingList.js
import React, { useEffect, useState } from 'react';
import { useSelector, useDispatch } from 'react-redux';
// Ensure these are correctly imported after fixing the export in shoppingListSlice.js
import { fetchCategories, fetchProductsByCategory } from './shoppingListSlice';
import { addProductToCart } from '../cart/cartSlice';
import CartDisplay from '../cart/CartDisplay';

function ShoppingList() {
  const dispatch = useDispatch();

  const categories = useSelector((state) => state.shoppingList.categories);
  const categoriesStatus = useSelector((state) => state.shoppingList.status);
  const categoriesError = useSelector((state) => state.shoppingList.error); // Get specific error message

  const productsForSelectedCategory = useSelector((state) => state.shoppingList.productsForSelectedCategory);
  const productsStatus = useSelector((state) => state.shoppingList.productsStatus);
  const productsError = useSelector((state) => state.shoppingList.error); // Get specific error message

  const [selectedCategoryDescription, setSelectedCategoryDescription] = useState('');
  const [selectedCategoryID, setSelectedCategoryID] = useState(null);

  // Local state to manage quantity for each product displayed in the list
  // Format: { [productID]: quantity }
  const [productQuantities, setProductQuantities] = useState({});

  // Effect to fetch categories on initial component mount
  useEffect(() => {
    if (categoriesStatus === 'idle') {
      dispatch(fetchCategories());
    }
  }, [categoriesStatus, dispatch]);

  // Effect to fetch products when a category is selected
  useEffect(() => {
    if (selectedCategoryDescription) {
      const category = categories.find(
        (cat) => cat.categoryDescription === selectedCategoryDescription
      );
      if (category) {
        setSelectedCategoryID(category.categoryID);
        dispatch(fetchProductsByCategory(category.categoryID));
      }
    } else {
      setSelectedCategoryID(null);
    }
    // Always reset product quantities when a new category is selected or cleared
    setProductQuantities({});
  }, [selectedCategoryDescription, categories, dispatch]); // Depend on categories to re-run if categories load later

  // Effect to initialize product quantities when products for a category are loaded
  useEffect(() => {
    const initialQuantities = {};
    if (productsStatus === 'succeeded' && productsForSelectedCategory.length > 0) {
      productsForSelectedCategory.forEach(product => {
        initialQuantities[product.productID] = 1; // Default quantity for each product is 1
      });
    }
    setProductQuantities(initialQuantities);
  }, [productsForSelectedCategory, productsStatus]); // Re-run when products or their status change

  const handleCategoryChange = (e) => {
    setSelectedCategoryDescription(e.target.value);
  };

  // Handler for changing individual product quantities
  const handleQuantityChange = (productID, newQuantity) => {
    // Ensure quantity is a number and at least 1
    const quantityValue = Math.max(1, parseInt(newQuantity, 10) || 1);
    setProductQuantities(prevQuantities => ({
      ...prevQuantities,
      [productID]: quantityValue,
    }));
  };

  // Handler for adding an individual product to the cart
  const handleAddProductToCart = (product) => {
    const quantity = productQuantities[product.productID] || 1; // Get current quantity or default to 1

    if (quantity > 0 && selectedCategoryID !== null) {
      dispatch(addProductToCart({
        id: Date.now() + '-' + product.id, // Create a more unique ID for cart item
        categoryID: selectedCategoryID,
        categoryDescription: selectedCategoryDescription,
        name: product.name,
        quantity: quantity,
      }));
      // Optional: Give user feedback that item was added
      // You could use a toast notification or a small modal here instead of alert
      console.log(`${product.name} (x${quantity}) added to cart!`);
      // Optionally reset the quantity input for the added product back to 1
      setProductQuantities(prev => ({ ...prev, [product.id]: 1 }));
    } else {
      console.warn('Cannot add product: Invalid quantity or no category selected.');
      // You could display an error message in the UI here
    }
  };

  return (
    <div className="p-4 max-w-4xl mx-auto bg-white rounded-lg shadow-md mt-8 font-inter">
      <h1 className="text-3xl font-bold mb-6 text-center text-indigo-700">Shopping List</h1>

      <div className="mb-6">
        <label htmlFor="category-select" className="block text-lg font-medium text-gray-700 mb-2">
          Select Category:
        </label>
        {categoriesStatus === 'loading' && <p className="text-blue-500 text-center">Loading categories...</p>}
        {categoriesStatus === 'failed' && (
          <p className="text-red-600 text-center">Error loading categories: {categoriesError || 'Unknown error'}</p>
        )}
        {categoriesStatus === 'succeeded' && (
          <select
            id="category-select"
            onChange={handleCategoryChange}
            value={selectedCategoryDescription}
            className="mt-1 block w-full pl-3 pr-10 py-2 text-base border-gray-300 focus:outline-none focus:ring-indigo-500 focus:border-indigo-500 sm:text-sm rounded-md shadow-sm"
          >
            <option value="">-- Select a Category --</option>
            {categories.map((category) => (
              <option key={category.categoryID} value={category.categoryDescription}>
                {category.categoryDescription}
              </option>
            ))}
          </select>
        )}
      </div>

      {/* Product List Section - only render if a category is selected */}
      {selectedCategoryDescription && (
        <div className="border border-gray-200 rounded-lg p-6 mb-6 bg-blue-50">
          <h3 className="text-xl font-semibold mb-4 text-indigo-600">Products in {selectedCategoryDescription}:</h3>

          {productsStatus === 'loading' && (
            <p className="text-blue-600 mt-4 text-center">Loading products...</p>
          )}

          {productsStatus === 'failed' && (
            <p className="text-red-600 mt-4 text-center">Error loading products: {productsError || 'Unknown error'}</p>
          )}

          {productsStatus === 'succeeded' && productsForSelectedCategory.length === 0 && (
            <p className="text-gray-500 mt-4 text-center">No products found for this category.</p>
          )}

          {productsStatus === 'succeeded' && productsForSelectedCategory.length > 0 && (
            <ul className="space-y-3">
              {productsForSelectedCategory.map((product) => (
                <li key={product.productID} className="flex flex-col sm:flex-row items-start sm:items-center space-y-2 sm:space-y-0 sm:space-x-4 bg-white p-3 rounded-md shadow-sm border border-gray-100">
                  <span className="flex-1 text-lg font-medium text-gray-800">
                    {product.productName}
                  </span>
                  <div className="flex items-center space-x-2">
                    <label htmlFor={`qty-${product.id}`} className="sr-only">Quantity for {product.name}</label>
                    <input
                      id={`qty-${product.id}`}
                      type="number"
                      min="1"
                      value={productQuantities[product.id] || 1} // Ensure default quantity
                      onChange={(e) => handleQuantityChange(product.id, e.target.value)}
                      className="w-24 px-2 py-1 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-indigo-500 focus:border-indigo-500 sm:text-sm text-center"
                    />
                    <button
                      onClick={() => handleAddProductToCart(product)}
                      className="inline-flex justify-center py-2 px-4 border border-transparent shadow-sm text-sm font-medium rounded-md text-white bg-green-600 hover:bg-green-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-green-500 transition duration-150 ease-in-out"
                    >
                      Add to Cart
                    </button>
                  </div>
                </li>
              ))}
            </ul>
          )}
        </div>
      )}

      <hr className="my-8 border-t-2 border-gray-200" />

      <CartDisplay />
    </div>
  );
}

export default ShoppingList;