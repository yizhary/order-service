// src/features/shoppingList/shoppingListSlice.js
import { createSlice, createAsyncThunk } from '@reduxjs/toolkit';

const API_BASE_URL = 'https://localhost:7077';
const ORDER_API_BASE_URL = 'http://localhost:3000';
// Async Thunk to fetch categories
 const fetchCategories = createAsyncThunk(
  'shoppingList/fetchCategories',
  async (_, { rejectWithValue }) => {
    try {
      const response = await fetch(`${API_BASE_URL}/api/Categories`);
      if (!response.ok) {
        const errorData = await response.json();
        return rejectWithValue(errorData);
      }
      const data = await response.json();
      // Store the full objects now, not just descriptions
      return data; // e.g., [{ categoryID: 222, categoryDescription: "בשר" }, ...]
    } catch (error) {
      return rejectWithValue(error.message);
    }
  }
);

// Async Thunk to fetch products for a specific category
 const fetchProductsByCategory = createAsyncThunk(
  'shoppingList/fetchProductsByCategory',
  async (categoryID, { rejectWithValue }) => {
    try {
      const response = await fetch(`${API_BASE_URL}/api/Products?categoryID=${categoryID}`);
      if (!response.ok) {
        const errorData = await response.json();
        return rejectWithValue(errorData);
      }
      const data = await response.json();
      console.log('Prods: ',data);
      return data; // e.g., [{ productID: 1, productName: "TV" }, { productID: 2, productName: "Laptop" }]
    } catch (error) {
      return rejectWithValue(error.message);
    }
  }
);

// Async Thunk to fetch product suggestions based on a prefix
 const fetchProductSuggestions = createAsyncThunk(
  'shoppingList/fetchProductSuggestions',
  async (prefix, { rejectWithValue }) => {
    try {
      // Only fetch if prefix is not empty
      if (!prefix) {
        return [];
      }
      const response = await fetch(`${API_BASE_URL}/api/Products?prefix=${prefix}`);
      if (!response.ok) {
        const errorData = await response.json();
        return rejectWithValue(errorData);
      }
      const data = await response.json();
      return data; // e.g., [{ productID: 1, productName: "Milk" }, { productID: 2, productName: "Meat" }]
    } catch (error) {
      return rejectWithValue(error.message);
    }
  }
);
 const sendOrder = createAsyncThunk(
    'shoppingList/sendOrder',
    async (orderData, { rejectWithValue }) => {
      try {
        console.log('orderData',JSON.stringify(orderData));
        const response = await fetch(`${ORDER_API_BASE_URL}/orders`, {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
          },
          body: JSON.stringify(orderData), // Send the cart items as the order data
        });
  
        if (!response.ok) {
          const errorData = await response.json();
          return rejectWithValue(errorData);
        }
  
        const result = await response.json();
        return result; // Server might return an order confirmation, ID, etc.
  
      } catch (error) {
        return rejectWithValue(error.message);
      }
    }
  );
  const shoppingListSlice = createSlice({
    name: 'shoppingList',
    initialState: {
      categories: [],
      productsForSelectedCategory: [],
      productSuggestions: [],
      status: 'idle', // For categories fetch
      productsStatus: 'idle', // For products by category fetch
      suggestionsStatus: 'idle', // For autocomplete suggestions fetch
      orderStatus: 'idle', // New status for order submission
      orderError: null, // New error for order submission
      error: null, // General error for other fetches
    },
    reducers: {
      clearProductSuggestions: (state) => {
        state.productSuggestions = [];
        state.suggestionsStatus = 'idle';
      },
      // Add a reducer to reset order status if needed (e.g., after success/failure display)
      resetOrderStatus: (state) => {
          state.orderStatus = 'idle';
          state.orderError = null;
      }
    },
  extraReducers: (builder) => {
    builder
      // Categories Fetch
      .addCase(fetchCategories.pending, (state) => {
        state.status = 'loading';
        state.error = null;
      })
      .addCase(fetchCategories.fulfilled, (state, action) => {
        state.status = 'succeeded';
        state.categories = action.payload;
      })
      .addCase(fetchCategories.rejected, (state, action) => {
        state.status = 'failed';
        state.error = action.payload || action.error.message;
      })
      // Products by Category Fetch
      .addCase(fetchProductsByCategory.pending, (state) => {
        state.productsStatus = 'loading';
        state.productsForSelectedCategory = []; // Clear previous products
        state.error = null;
      })
      .addCase(fetchProductsByCategory.fulfilled, (state, action) => {
        state.productsStatus = 'succeeded';
        state.productsForSelectedCategory = action.payload;
      })
      .addCase(fetchProductsByCategory.rejected, (state, action) => {
        state.productsStatus = 'failed';
        state.error = action.payload || action.error.message;
      })
      // Product Suggestions Fetch
      .addCase(fetchProductSuggestions.pending, (state) => {
        state.suggestionsStatus = 'loading';
        // Do not clear suggestions here, allow previous suggestions to remain until new ones arrive
        state.error = null;
      })
      .addCase(fetchProductSuggestions.fulfilled, (state, action) => {
        state.suggestionsStatus = 'succeeded';
        state.productSuggestions = action.payload; // Update suggestions
      })
      .addCase(fetchProductSuggestions.rejected, (state, action) => {
        state.suggestionsStatus = 'failed';
        state.error = action.payload || action.error.message;
        state.productSuggestions = []; // Clear suggestions on error
      })
       // sendOrder Thunk reducers
       .addCase(sendOrder.pending, (state) => {
        state.orderStatus = 'loading';
        state.orderError = null;
      })
      .addCase(sendOrder.fulfilled, (state, action) => {
        state.orderStatus = 'succeeded';
        // You might want to store the order confirmation data here if your API returns it
        // state.latestOrderConfirmation = action.payload;
      })
      .addCase(sendOrder.rejected, (state, action) => {
        state.orderStatus = 'failed';
        state.orderError = action.payload || action.error.message;
      });
      
  },
});

export const { clearProductSuggestions, resetOrderStatus } = shoppingListSlice.actions;
export { fetchCategories, fetchProductsByCategory, fetchProductSuggestions, sendOrder }; // Ensure sendOrder is exported

export default shoppingListSlice.reducer;