// src/features/cart/cartSlice.js
import { createSlice } from '@reduxjs/toolkit';

const cartSlice = createSlice({
  name: 'cart',
  initialState: {
    items: [], // [{ id, categoryID, categoryDescription, name, quantity }]
  },
  reducers: {
    addProductToCart: (state, action) => {
      const newItem = action.payload;
      const existingItem = state.items.find(
        item => item.name === newItem.name && item.categoryID === newItem.categoryID
      );

      if (existingItem) {
        existingItem.quantity += newItem.quantity;
      } else {
        state.items.push(newItem);
      }
    },
    removeProductFromCart: (state, action) => {
      state.items = state.items.filter(item => item.id !== action.payload);
    },
    updateProductQuantity: (state, action) => {
      const { id, quantity } = action.payload;
      const itemToUpdate = state.items.find(item => item.id === id);
      if (itemToUpdate) {
        itemToUpdate.quantity = quantity;
      }
    },
    clearCart: (state) => { // Make sure this action is defined
      state.items = [];
    },
  },
});

export const { addProductToCart, removeProductFromCart, updateProductQuantity, clearCart } = cartSlice.actions;
export default cartSlice.reducer;