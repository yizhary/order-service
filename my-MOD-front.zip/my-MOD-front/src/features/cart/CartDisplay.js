// src/features/cart/CartDisplay.js
import React from 'react';
import { useSelector, useDispatch } from 'react-redux';
import { removeProductFromCart, updateProductQuantity } from './cartSlice';
import { Link } from 'react-router-dom'; // For navigation to summary screen

function CartDisplay() {
  const cartItems = useSelector((state) => state.cart.items);
  const dispatch = useDispatch();

  const handleRemove = (id) => {
    dispatch(removeProductFromCart(id));
  };

  const handleQuantityChange = (id, newQuantity) => {
    if (newQuantity > 0) {
      dispatch(updateProductQuantity({ id, quantity: Number(newQuantity) }));
    }
  };

  return (
    <div>
      <h2>Your Cart</h2>
      {cartItems.length === 0 ? (
        <p>Your cart is empty.</p>
      ) : (
        <ul>
          {cartItems.map((item) => (
            <li key={item.id}>
              {item.name} ({item.category}) -
              <input
                type="number"
                min="1"
                value={item.quantity}
                onChange={(e) => handleQuantityChange(item.id, e.target.value)}
              />
              <button onClick={() => handleRemove(item.id)}>Remove</button>
            </li>
          ))}
        </ul>
      )}
      {cartItems.length > 0 && (
        <Link to="/summary">
          <button>Proceed to Order Summary</button>
        </Link>
      )}
    </div>
  );
}

export default CartDisplay;