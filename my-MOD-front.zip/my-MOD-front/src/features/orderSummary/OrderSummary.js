// src/features/orderSummary/OrderSummary.js
import React, { useEffect } from 'react';
import { useSelector, useDispatch } from 'react-redux';
import { Link, useNavigate } from 'react-router-dom'; // Import useNavigate for redirection
import { sendOrder, resetOrderStatus } from '../shoppingList/shoppingListSlice'; // Import sendOrder and resetOrderStatus
import { clearCart } from '../cart/cartSlice'; // Import clearCart

function OrderSummary() {
  const dispatch = useDispatch();
  const navigate = useNavigate(); // Hook for navigation

  const cartItems = useSelector((state) => state.cart.items);
  const orderStatus = useSelector((state) => state.shoppingList.orderStatus);
  const orderError = useSelector((state) => state.shoppingList.orderError);

  // Clear order status when component mounts/unmounts, to reset messages
  useEffect(() => {
    return () => {
      dispatch(resetOrderStatus());
    };
  }, [dispatch]);

  // Handle successful order submission
  useEffect(() => {
    if (orderStatus === 'succeeded') {
      alert('Order confirmed successfully!'); // Simple alert for feedback
      dispatch(clearCart()); // Clear the cart after successful order
      dispatch(resetOrderStatus()); // Reset status
      navigate('/'); // Redirect back to shopping list
    }
  }, [orderStatus, dispatch, navigate]); // Add navigate to dependency array

  const handleConfirmOrder = () => {
    if (cartItems.length === 0) {
      alert('Your cart is empty. Please add items before confirming your order.');
      return;
    }

    // You might want to add more data to your order here (e.g., user info, date)
    const orderData = {
      orderId: 'ORD-' + Date.now(), // Example: generate a simple client-side ID
      orderDate: new Date().toISOString(),
      items: cartItems.map(item => ({
        productId: item.id, // Assuming cart item 'id' is good for backend productId
        productName: item.name,
        categoryId: item.categoryID,
        quantity: item.quantity,
      })),
      totalItems: cartItems.length,
      // You can add more fields like customerId, shippingAddress, etc.
    };

    dispatch(sendOrder(orderData));
  };

  return (
    <div className="p-4 max-w-2xl mx-auto bg-white rounded-lg shadow-md mt-8">
      <h1 className="text-3xl font-bold mb-6 text-center text-green-700">Order Summary</h1>

      {cartItems.length === 0 ? (
        <p className="text-gray-600 text-center">Your cart is empty. Please add items from the shopping list.</p>
      ) : (
        <ul className="space-y-3 mb-6">
          {cartItems.map((item) => (
            <li key={item.id} className="flex justify-between items-center bg-gray-50 p-4 rounded-md shadow-sm border border-gray-200">
              <span className="text-lg font-medium text-gray-800">
                {item.name} ({item.categoryDescription})
              </span>
              <span className="text-md text-gray-600">
                Quantity: <span className="font-semibold">{item.quantity}</span>
              </span>
            </li>
          ))}
        </ul>
      )}

      {/* Order Status Feedback */}
      {orderStatus === 'loading' && (
        <p className="text-blue-600 text-center mb-4">Confirming your order...</p>
      )}
      {orderStatus === 'failed' && (
        <p className="text-red-600 text-center mb-4">Error confirming order: {orderError || 'Please try again.'}</p>
      )}

      <div className="mt-8 flex justify-between items-center">
        <Link to="/">
          <button className="inline-flex justify-center py-2 px-6 border border-transparent shadow-sm text-base font-medium rounded-md text-white bg-indigo-600 hover:bg-indigo-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-indigo-500">
            Back to Shopping List
          </button>
        </Link>

        <button
          onClick={handleConfirmOrder}
          disabled={cartItems.length === 0 || orderStatus === 'loading'}
          className="inline-flex justify-center py-2 px-6 border border-transparent shadow-sm text-base font-medium rounded-md text-white bg-green-600 hover:bg-green-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-green-500 disabled:opacity-50 disabled:cursor-not-allowed"
        >
          אשר הזמנה (Confirm Order)
        </button>
      </div>
    </div>
  );
}

export default OrderSummary;